/* asset-check: small JS probe to verify static assets are served correctly */
window.__zaco_asset_check = true;
