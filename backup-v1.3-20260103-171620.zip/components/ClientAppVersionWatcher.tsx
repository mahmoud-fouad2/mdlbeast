"use client"
import React from 'react'
import AppVersionWatcher from './AppVersionWatcher'

export default function ClientAppVersionWatcher() {
  return <AppVersionWatcher />
}
