declare module '@pdf-lib/fontkit' {
  const fontkit: any
  export default fontkit
}

declare module 'fontkit' {
  const fontkit: any
  export default fontkit
}
