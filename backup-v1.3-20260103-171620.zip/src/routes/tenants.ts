import express from "express"
import { query } from "../config/database"
import type { Request, Response } from "express"
import { authenticateToken, isAdmin } from "../middleware/auth"
import { getSignedDownloadUrl } from "../lib/r2-storage"
const router = express.Router()

// Require authentication for tenant operations
router.use(authenticateToken)

// Create tenant
router.post("/", isAdmin, async (req: Request, res: Response) => {
  try {
    const { name, slug, logo_url, signature_url } = req.body
    const ins = await query(
      "INSERT INTO tenants (name, slug, logo_url, signature_url) VALUES ($1,$2,$3,$4) RETURNING *",
      [name, slug, logo_url, signature_url]
    )
    res.status(201).json(ins.rows[0])
  } catch (err: any) {
    console.error("Create tenant error:", err)
    res.status(500).json({ error: "Failed to create tenant" })
  }
})

// List tenants
router.get("/", async (_req: Request, res: Response) => {
  try {
    const r = await query("SELECT * FROM tenants ORDER BY created_at DESC")
    
    // Convert signature_url to signed URL if it exists
    const tenantsWithSignedUrls = await Promise.all(
      r.rows.map(async (tenant) => {
        if (tenant.signature_url && tenant.signature_url.includes('r2.cloudflarestorage.com')) {
          try {
            // Extract key from URL: signatures/XXX.png
            const urlParts = tenant.signature_url.split('/')
            const key = urlParts.slice(-2).join('/') // signatures/filename.ext
            tenant.signature_url = await getSignedDownloadUrl(key)
          } catch (err) {
            console.error('Failed to generate signed URL for tenant signature:', err)
          }
        }
        return tenant
      })
    )
    
    res.json(tenantsWithSignedUrls)
  } catch (err: any) {
    console.error("List tenants error:", err)
    res.status(500).json({ error: "Failed to list tenants" })
  }
})

// Update tenant
router.put('/:id', isAdmin, async (req: Request, res: Response) => {
  try {
    const { id } = req.params
    const { name, slug, logo_url, signature_url } = req.body
    
    // Build dynamic update query to only update provided fields
    const updates: string[] = []
    const values: any[] = []
    let paramIndex = 1
    
    if (name !== undefined) {
      updates.push(`name = $${paramIndex++}`)
      values.push(name)
    }
    if (slug !== undefined) {
      updates.push(`slug = $${paramIndex++}`)
      values.push(slug)
    }
    if (logo_url !== undefined) {
      updates.push(`logo_url = $${paramIndex++}`)
      values.push(logo_url)
    }
    if (signature_url !== undefined) {
      updates.push(`signature_url = $${paramIndex++}`)
      values.push(signature_url)
    }
    
    if (updates.length === 0) {
      return res.status(400).json({ error: 'No fields to update' })
    }
    
    updates.push(`updated_at = CURRENT_TIMESTAMP`)
    values.push(id)
    
    const sql = `UPDATE tenants SET ${updates.join(', ')} WHERE id = $${paramIndex} RETURNING *`
    const r = await query(sql, values)
    
    if (r.rows.length === 0) return res.status(404).json({ error: 'Tenant not found' })
    res.json(r.rows[0])
  } catch (err: any) {
    console.error('Update tenant error:', err)
    res.status(500).json({ error: 'Failed to update tenant' })
  }
})

// Delete tenant
router.delete('/:id', isAdmin, async (req: Request, res: Response) => {
  try {
    const { id } = req.params
    const r = await query('DELETE FROM tenants WHERE id = $1 RETURNING id', [id])
    if (r.rows.length === 0) return res.status(404).json({ error: 'Tenant not found' })
    res.json({ deleted: 1 })
  } catch (err: any) {
    console.error('Delete tenant error:', err)
    res.status(500).json({ error: 'Failed to delete tenant' })
  }
})

export default router
