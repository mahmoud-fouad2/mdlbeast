-- 12_create_backups_table.sql
CREATE TABLE IF NOT EXISTS backups (
  id SERIAL PRIMARY KEY,
  name VARCHAR(512) NOT NULL,
  uploaded_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
